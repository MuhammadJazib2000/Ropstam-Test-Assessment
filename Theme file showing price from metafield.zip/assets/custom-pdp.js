(function() {
  // Get metafield data
  const widthOptions = window.productMetafields.widthOptions;
  const pricingTable = window.productMetafields.pricingTable;
  
  // Get DOM elements
  const widthSelect = document.getElementById('width-select');
  const dropSelect = document.getElementById('drop-select');
  const priceDisplay = document.getElementById('calculated-price');
  const addToCartBtn = document.querySelector('[name="add"]');
  
  let currentFabricPanels = null;
  let currentDrop = null;
  
  // Function to update price
  function updatePrice() {
    if (!currentFabricPanels || !currentDrop) {
      priceDisplay.textContent = 'Select options to see price';
      addToCartBtn.disabled = true;
      return;
    }
    
    // Get price from pricing table
    const price = pricingTable[currentFabricPanels]?.[currentDrop];
    
    if (price) {
      priceDisplay.textContent = `$${price.toFixed(2)}`;
      addToCartBtn.disabled = false;
      
      // Update Add to Cart button text
      addToCartBtn.textContent = `Add to Cart - $${price.toFixed(2)}`;
    } else {
      priceDisplay.textContent = 'Price not available';
      addToCartBtn.disabled = true;
    }
  }
  
  // Width change handler
  widthSelect.addEventListener('change', function() {
    const selectedWidth = this.value;
    
    if (selectedWidth) {
      // Get fabric panels needed for this width
      currentFabricPanels = widthOptions[selectedWidth];
      console.log(`Width ${selectedWidth}" requires ${currentFabricPanels} fabric panels`);
    } else {
      currentFabricPanels = null;
    }
    
    updatePrice();
  });
  
  // Drop change handler
  dropSelect.addEventListener('change', function() {
    currentDrop = this.value || null;
    updatePrice();
  });
  
  // Handle Add to Cart
  addToCartBtn.addEventListener('click', function(e) {
    e.preventDefault();
    
    if (!currentFabricPanels || !currentDrop) {
      alert('Please select both width and drop');
      return;
    }
    
    // Find the correct variant ID based on fabric panels and drop
    // You'll need to map this to your actual variant structure
    const variantId = findVariantId(currentFabricPanels, currentDrop);
    
    if (variantId) {
      // Add to cart via AJAX
      fetch('/cart/add.js', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: variantId,
          quantity: 1
        })
      })
      .then(response => response.json())
      .then(data => {
        console.log('Added to cart:', data);
        // Trigger cart drawer or redirect
        window.location.href = '/cart';
      })
      .catch(error => {
        console.error('Error:', error);
        alert('Error adding to cart');
      });
    }
  });
  
  // Helper function to find variant ID
  function findVariantId(panels, drop) {
    // This needs to match your actual variant structure
    // You may need to store variant IDs in metafields or fetch via API
    const variants = {{ product.variants | json }};
    
    return variants.find(v => {
      return v.option1 == `${panels} Panels` && v.option2 == drop;
    })?.id;
  }
})();